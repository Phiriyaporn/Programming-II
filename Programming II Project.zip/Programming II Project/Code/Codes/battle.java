package Programming_II;

public interface battle {
	public void fight();

}
