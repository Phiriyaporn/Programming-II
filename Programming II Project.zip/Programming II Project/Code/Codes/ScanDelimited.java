package Programming_II;


import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

	public class ScanDelimited {

	 public static void main(String[] args) {
	  // delimited file
	  File file = new File("weapon.csv");
	  Scanner sc = null;
	  try {
	   sc = new Scanner(file);
	   // Check if there is another line of input
	   while(sc.hasNextLine()){
	    String str = sc.nextLine();
	    System.out.print(parseLine(str));
	   }
	   
	  } catch (IOException  exp) {
	   // TODO Auto-generated catch block
	   exp.printStackTrace();
	  }
	  
	  sc.close();
	 }
	 
	 private static ArrayList<Weapon> parseLine(String str){
	  ArrayList<Weapon> wpList = new ArrayList<Weapon>();
	  String book, author, price;
	  Scanner sc = new Scanner(str);
	  sc.useDelimiter(",");

	  // Check if there is another line of input
	  while(sc.hasNext()){
	   String name = sc.next();
	   int damage = sc.nextInt();
	   int worth = sc.nextInt();
	   Weapon temp =new Weapon(name,damage,worth);
	   wpList.add(temp);
	  }
	  sc.close();
	  return wpList;
	 } 
	}

