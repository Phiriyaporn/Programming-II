package Programming_II;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class gamePlay extends HeroNew {
	String nameHero;
	Scanner console = new Scanner(System.in);

	public gamePlay(String PlayerName) {
		super(PlayerName);
	}

	// Get the player to enter a desired name
	public void getPlayerName() {
		System.out.print("Type 'start' to start the game.");
		String start = console.nextLine();
		checkQuit(start);
		while (!start.equalsIgnoreCase("start")) {
			System.out.print("you need to type 'start':");
			start = console.nextLine();
		}

		System.out.print("                                       Enter Character Name:");
		String name = console.nextLine();
		checkQuit(name);
		this.nameHero = name;
		String gameName = "Welcome to Fundamentality.......\n";
		// loop to print the welcome part character by character
		for (int i = 0; i < gameName.length(); i++) {
			System.out.printf("%c", gameName.charAt(i));
			try {
				Thread.sleep(50);// 0.5s pause between characters
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
			}
		}
	}

	// Method to print the story
	public void printStory() {
		String story = "=======================================================================\n"
				+ "Once upon a time, there was a young child by the name of " + this.nameHero
				+ ". Their family live peacefully \n"
				+ "at the edge of the forest in a well build wooden house. Today was their 16th birthday,\n"
				+ "and the father have a surprise for them. Today is the day you become a real hunter!\n"
				+ "I have a great hunt for you, and should you complete it, I will acknowledge your skills,\n"
				+ "and allow you even hunt on your own!\" The father exclaims to his child at the table.\n"
				+ "\"Now now, finish your breakfast first. Then you can leave.\" The mother calms the eager child\n"
				+ "down with a warm smile, as she pack up the food and supplies for her child's hunt.\n" + "\n"
				+ this.nameHero
				+ " did as they were told, gulfing down the breakfast in a flash. And in moments, they were waving\n"
				+ "goodbye to their parents, heading into the woods excited and ready to prove themselves to their Father.\n"
				+ "\n"
				+ "The target was the elusive White Stag of the Forest. Some calls it the white phantom, while others \n"
				+ "call it the guardian beast. Either way, they will be bringing its renowned crystal antlers back \n"
				+ "to their father. Trekking the beast was tough, but the child was smart. Soon enough, the white stag \n"
				+ "was in sight, as magnificent and eerie as people describe it in their tales with glistening crystal \n"
				+ "antlers in the rays of sunlight that pierce through the canopy of the forest. \n"
				+ "It stands at an edge of the pond, creating ripples in the reflective water as it leans in to drink.\n"
				+ "\n"
				+ "The child calms their breath, and knocks the arrow onto the bow, taking a brief moment to aim \n"
				+ "before letting it loose. The aim was true, and a swift arrow flies straight at the stag's heart. \n"
				+ "With a sudden shrieking roar, the forest trembles, as the stag falls dead onto the ground.\n" + "\n"
				+ "The child jumps joyously, as they rush towards the trophy, but the forest trembles once more, \n"
				+ "as the ground beneath them shook. The corpose of the dead stag distorts, defying reality \n"
				+ "as it collapse upon itself, creating a black vaccum that gets bigger with each second. \n"
				+ "The child tries to run away, but the force was too strong, and they were sucked into the \n"
				+ "infinite darkness.......but soon, awaken to a familiar patch of grass, in front of their own home.\n \n";
		for (int i = 0; i < story.length(); i++) {
			System.out.printf("%c", story.charAt(i));
			try {
				Thread.sleep(5);// 1/50th of a second to pause
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
			}
		}
	}

	public void printTutorial() {

		System.out.println("\n---------------------------------How to play-----------------------------");
		System.out.println("Navigate through by choosing the options given.");
		System.out.println("Type 'quit' or 'exit' anywhere in the game to quit");
		System.out.println("You will respawn when you die, but once you exit the game, you start anew");
		System.out.println("\n\nGood luck........");
	}

	/// methods to scan data from files for weapons
	private static Weapon parseLineWeapon(String str) {
		// ArrayList<Weapon> wpList = new ArrayList<Weapon>();
		Weapon wp = new Weapon("", 0, 0);
		Scanner sc = new Scanner(str);
		sc.useDelimiter(",");

		// Check if there is another line of input
		while (sc.hasNext()) {
			String name = sc.next();
			int damage = sc.nextInt();
			int worth = sc.nextInt();
			Weapon temp = new Weapon(name, damage, worth);
			wp = temp;
		}
		sc.close();
		return wp;
	}

	/// method to scan data from file and create armor
	private static Armor parseLineArmor(String str) {
		Armor am = new Armor("", 0, 0);
		Scanner sc = new Scanner(str);
		sc.useDelimiter(",");

		// Check if there is another line of input
		while (sc.hasNext()) {
			String name = sc.next();
			int protection_lv = sc.nextInt();
			int worth = sc.nextInt();
			Armor temp = new Armor(name, protection_lv, worth);
			am = temp;
		}
		sc.close();
		return am;
	}

	// Scan information for bossMonster
	private static boss_monster parseLineBM(String str) {
		boss_monster bm = new boss_monster("", 0, 0, 0, 0);
		Scanner sc = new Scanner(str);
		sc.useDelimiter(",");

		// Check if there is another line of input
		while (sc.hasNext()) {
			String name = sc.next();
			int health = sc.nextInt();
			int defense = sc.nextInt();
			int damage = sc.nextInt();
			int heal_count = sc.nextInt();
			boss_monster temp = new boss_monster(name, health, defense, damage, heal_count);
			bm = temp;
		}
		sc.close();
		return bm;
	}

	// Scan information for normal_monster
	private static Monster parseLineNM(String str) {
		Monster nm = new Monster("", "", 0, 0, 0);
		Scanner sc = new Scanner(str);
		sc.useDelimiter(",");

		// Check if there is another line of input
		while (sc.hasNext()) {
			String name = sc.next();
			String type = sc.next();
			int health = sc.nextInt();
			int defense = sc.nextInt();
			int damage = sc.nextInt();
			Monster temp = new Monster(name, type, health, defense, damage);
			nm = temp;
		}
		sc.close();
		return nm;
	}

	// method to check to quit game
	public void checkQuit(String input) {
		if (input.equalsIgnoreCase("quit") || input.equalsIgnoreCase("exit")) {
			System.out.println("Bye For now!");
			System.exit(0);
		}
	}

	// A method for the game play
	public void Play() {
		// scan files and load information
		// delimited file
		// Scan the weapon file
		ArrayList<Weapon> allWeapons = new ArrayList<Weapon>();
		File file = new File("weapon.csv");
		Scanner sc = null;
		try {
			sc = new Scanner(file);
			// Check if there is another line of input
			while (sc.hasNextLine()) {
				String str = sc.nextLine();
				allWeapons.add((parseLineWeapon(str)));
			}

		} catch (IOException exp) {
			exp.printStackTrace();
		}

		sc.close();

		/// Scan the armor file
		ArrayList<Armor> allArmor = new ArrayList<Armor>();
		File file2 = new File("armor.csv");
		Scanner sc2 = null;
		try {
			sc2 = new Scanner(file2);
			// Check if there is another line of input
			while (sc2.hasNextLine()) {
				String str = sc2.nextLine();
				allArmor.add((parseLineArmor(str)));
			}

		} catch (IOException exp) {
			exp.printStackTrace();
		}

		sc2.close();

		// Scan the boss monster file
		ArrayList<boss_monster> boss_monsters = new ArrayList<boss_monster>();
		File file3 = new File("bossmonster.csv");
		Scanner sc3 = null;
		try {
			sc3 = new Scanner(file3);
			// Check if there is another line of input
			while (sc3.hasNextLine()) {
				String str = sc3.nextLine();
				boss_monsters.add((parseLineBM(str)));
			}

		} catch (IOException exp) {
			exp.printStackTrace();
		}

		sc3.close();
		// Scan the normal_Monster file
		ArrayList<Monster> monsterList = new ArrayList<Monster>();
		File file4 = new File("monster.csv");
		Scanner sc4 = null;
		try {
			sc4 = new Scanner(file4);
			// Check if there is another line of input
			while (sc4.hasNextLine()) {
				String str = sc4.nextLine();
				monsterList.add((parseLineNM(str)));
			}

		} catch (IOException exp) {
			exp.printStackTrace();
		}

		sc4.close();
		// Add all the armors and weapons into a shop
		ArrayList<Item> shopItems = new ArrayList<Item>();
		shopItems.addAll(allArmor);
		shopItems.addAll(allWeapons);
		// Room Initialization and adding things to room
		// ***Area 1******/////
		ArrayList<Item> emptyRoom = new ArrayList<Item>();// for empty room
		Item nth = new Item("Nothing", "nth", 0);
		emptyRoom.add(nth);
		ArrayList<Item> wp = new ArrayList<Item>();
		wp.add((allWeapons.get(0)));
		ArrayList<Item> am = new ArrayList<Item>();
		am.add((allArmor.get(0)));
		RoomNew r2a1 = new RoomNew(2,
				"You stand before the entrance gates to your own little home. However, the air is still, and the grass seems lifeless.\n"
						+ "\n"
						+ "To the (EAST) is the front of your house. A decently looking Cabin built by your own father.\n"
						+ "\n" + "\n=================================================================",
				0, 4, 0, 0, "nth", emptyRoom);
		RoomNew r4a1 = new RoomNew(4,
				"You are at the front proch of your home. The eeriness of the atmosphere makes it look unwelcoming.\n"
						+ "The front door seems to be the only entrance in.\n" + "\n"
						+ "To the (WEST) is the entrance gate of the house.\n"
						+ "To the (EAST) is the toolshed where your Father likes to keep his spare hunting equipment.\n"
						+ "To the (SOUTH) is the entrance into the cabin." + "\n"
						+ "\n=================================================================",
				0, 6, 8, 2, "it", am);
		RoomNew r6a1 = new RoomNew(6,
				"Inside the toolshed is filled with many equipments your father had crafted, or bought.\n"
						+ "However, most of them look rusted and weathered.\n" + "\n"
						+ "To the (WEST) is back out to the front porch.\n" + "---------------------\n" + "ITEMS:\n"
						+ "\n"
						+ "Out of the corner of your eyes, you see a glint of a shiny axe among the rusty equipment.\n"
						+ "\n" + "\n+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++",
				0, 0, 10, 4, "it", wp);
		RoomNew r8a1 = new RoomNew(8,
				"The inside of the Cabin seems like a massive fire had engulfed the place, leaving no trace of color or life in it.\n"
						+ "The rooms are all wrong, and your parents are no where to be found. Instead of the doorway to the dining room,\n"
						+ "is an eerie looking wooden door.\n" + "\n"
						+ "You hunter instincts tell you that danger lurks behind the eerie door.\n" + "\n"
						+ "You can exit the Cabin by going back (NORTH).\n"
						+ "The room with the eerie looking wooden door is to the (EAST).\n" + "\n"
						+ "\n=================================================================",
				4, 10, 0, 0, "mn", monsterList.get(0));
		RoomNew r10a1 = new RoomNew(10,
				"You push through the wooden door to find a shadowy creature writhing in the dark corner of the room.\n"
						+ "Then it notices you, and lunge at you with a snarl!" + "\n"
						+ "\n=================================================================",
				6, 0, 0, 8, "mn", boss_monsters.get(0));
		// ******Area 2******/////
		ArrayList<Item> wp2 = new ArrayList<Item>();
		wp2.add((allWeapons.get(1)));
		wp2.add((allWeapons.get(2)));
		ArrayList<Item> am2 = new ArrayList<Item>();
		am2.add((allArmor.get(1)));
		am2.add((allArmor.get(2)));
		RoomNew r12a2 = new RoomNew(12,
				"You are in a cave-like surrounding, where the ceiling is just infinite darkness. However, little glowing fireflies flood the cave floor,\n"
						+ "illuminating the path for you.\n" + "\n" + "To the (SOUTH) is a path out of the area.\n"
						+ "\n" + "\n================================================",
				0, 0, 0, 14, "mn", monsterList.get(1));
		RoomNew r14a2 = new RoomNew(14,
				"There are a lot of luminescent flora littered about the cave floor. \n" + "\n"
						+ "To the (NORTH) is the small caveroom with the Blue Flower.\n"
						+ "To the (EAST) is a path deeper into the caves.\n" + "\n"
						+ "\n================================================",
				12, 16, 0, 0, "it", am2);
		RoomNew r16a2 = new RoomNew(16,
				"The walls seems to be fused with glowing moss the light up the damp, rocky path in this room.\n" + "\n"
						+ "To the (WEST) is the path back.\n"
						+ "To the (EAST) is a path deeper into the cave, where the path seems to get wider.\n" + "\n"
						+ "\n================================================",
				0, 20, 24, 14, "nth", emptyRoom);
		RoomNew r18a2 = new RoomNew(18,
				"There is a giant glowing mushroom in the center of the room. It illuminate the hole area with a faint, comforting glow.\n"
						+ "\n" + "To the (NORTH) is a strangely paved rocky pathway.\n" + "\n"
						+ "To the (SOUTH) is a dark tunnel that seems to be void of any glowing moss or flora.\n" + "\n"
						+ "\n================================================",
				0, 0, 20, 0, "mn", monsterList.get(2));
		RoomNew r20a2 = new RoomNew(20,
				"You entered into a well lit room with floor boards and wooden walls, despite being in a dark luminescent cave just a second ago.\n"
						+ " A red panda with a bandana seems to be sitting behind a large counter, waiting for you to approach.\n"
						+ "\n"
						+ "\"Come come! I have goods you may want to (BUY)! Or you could (SELL) me some goods you have!\" the Red Panda spoke with a jovial tone.\n"
						+ "\n"
						+ "\"Or have you just come to (TALK) and banter with the greatest, interdimensional travelling merchant; me!\" it adds with a wink at you.\n"
						+ "\n" + "You understood some of the words it said." + "\n"
						+ "\n================================================",
				18, 0, 22, 16, "shop", shopItems);
		RoomNew r22a2 = new RoomNew(22,
				"This area is much much darker with, little to no light illuminating this place. It's as if the wild flora purposely \n"
						+ "avoid growing in this place.\n" + "\n"
						+ "To the (NORTH) is the room with the giant glowing mushroom.\n"
						+ "To the (WEST) is a cave with an eerie glowing red light. \n"
						+ "Your hunter instincts tell you that great danger is ahead there.\n" + "\n"
						+ "\n================================================",
				20, 0, 0, 24, "it", wp2);
		RoomNew r24a2 = new RoomNew(24,
				"The large, open caveroom is lit with a ghostly red light emitting from a seemingly out of place broken lamp post \n"
						+ "in the middle of the cave floor. As you approach closer, the darkness seems to circle in around the corners of the area. \n"
						+ "\n"
						+ "Then, the lamp post suddenly shakes, as it rose up from the ground, carried up a ghastly looking abomination \n"
						+ "that phased out from the ground.\n" + "\n"
						+ "\"Lost.....Darkness....Hunger....Death....\" the creature mutters the words, before it staggers and sways wildly towards you!\n"
						+ "\n" + "\n================================================",
				16, 22, 0, 0, "mn", boss_monsters.get(1));
		// ***Area 3*****///
		ArrayList<Item> wp3 = new ArrayList<Item>();
		wp3.add((allWeapons.get(3)));
		wp3.add((allWeapons.get(4)));
		wp3.add((allWeapons.get(5)));
		ArrayList<Item> am3 = new ArrayList<Item>();
		am3.add((allArmor.get(3)));
		am3.add((allArmor.get(4)));
		ArrayList<Item> wp4 = new ArrayList<Item>();
		wp4.add((allWeapons.get(6)));
		RoomNew r26a3 = new RoomNew(26, "###", 0, 0, 28, 0, "nth", emptyRoom);
		RoomNew r28a3 = new RoomNew(28, "###", 0, 32, 30, 0, "it", am3);
		RoomNew r30a3 = new RoomNew(30, "###", 28, 0, 0, 0, "mn", monsterList.get(3));
		RoomNew r32a3 = new RoomNew(32, "###", 0, 34, 0, 28, "mn", monsterList.get(4));
		RoomNew r34a3 = new RoomNew(34, "####", 36, 40, 0, 32, "shop", shopItems);
		RoomNew r36a3 = new RoomNew(36, "###", 0, 0, 34, 0, "mn", monsterList.get(8));
		RoomNew r38a3 = new RoomNew(38, "###", 0, 0, 40, 36, "it", wp3);
		RoomNew r40a3 = new RoomNew(26, "###", 38, 0, 42, 34, "it", wp4);
		RoomNew r42a3 = new RoomNew(42, "###", 40, 0, 0, 0, "mn", boss_monsters.get(2));
		// *******Area 4////////
		ArrayList<Item> wp5 = new ArrayList<Item>();
		wp5.add((allWeapons.get(7)));
		wp5.add((allWeapons.get(8)));
		wp5.add((allWeapons.get(9)));
		ArrayList<Item> am4 = new ArrayList<Item>();
		am4.add((allArmor.get(5)));
		am4.add((allArmor.get(6)));
		ArrayList<Item> am5 = new ArrayList<Item>();
		am5.add((allArmor.get(4)));
		RoomNew r44a4 = new RoomNew(44, "###", 0, 0, 46, 0, "mn", monsterList.get(2));
		RoomNew r46a4 = new RoomNew(46, "###", 44, 50, 48, 0, "it", wp5);
		RoomNew r48a4 = new RoomNew(48, "###", 46, 52, 0, 0, "mn", monsterList.get(5));
		RoomNew r50a4 = new RoomNew(50, "###", 0, 58, 52, 46, "nth", emptyRoom);
		RoomNew r52a4 = new RoomNew(52, "###", 50, 60, 54, 48, "mn", monsterList.get(11));
		RoomNew r54a4 = new RoomNew(54, "###", 52, 0, 0, 0, "it", am4);
		RoomNew r56a4 = new RoomNew(56, "###", 0, 0, 58, 0, "shop", shopItems);
		RoomNew r58a4 = new RoomNew(58, "###", 56, 0, 58, 50, "it", am5);
		RoomNew r60a4 = new RoomNew(60, "###", 58, 0, 0, 52, "mn", boss_monsters.get(3));
		// ********Area 5////////
		ArrayList<Item> wp6 = new ArrayList<Item>();
		wp6.add((allWeapons.get(10)));
		wp6.add((allWeapons.get(11)));
		wp6.add((allWeapons.get(12)));

		RoomNew r62a5 = new RoomNew(60, "###", 0, 66, 64, 0, "it", wp6);
		RoomNew r64a5 = new RoomNew(64, "###", 62, 68, 0, 0, "mn", monsterList.get(7));
		RoomNew r66a5 = new RoomNew(66, "###", 0, 0, 68, 62, "mn", boss_monsters.get(4));
		RoomNew r68a5 = new RoomNew(68, "###", 66, 0, 0, 64, "mn", boss_monsters.get(5));

		// Add all the rooms into a list
		ArrayList<RoomNew> rList = new ArrayList<RoomNew>();
		rList.add(r2a1);
		rList.add(r4a1);
		rList.add(r6a1);
		rList.add(r8a1);
		rList.add(r10a1);

		rList.add(r12a2);
		rList.add(r14a2);
		rList.add(r16a2);
		rList.add(r18a2);
		rList.add(r20a2);
		rList.add(r22a2);
		rList.add(r24a2);

		rList.add(r26a3);
		rList.add(r28a3);
		rList.add(r30a3);
		rList.add(r32a3);
		rList.add(r34a3);
		rList.add(r38a3);
		rList.add(r40a3);
		rList.add(r42a3);

		rList.add(r44a4);
		rList.add(r46a4);
		rList.add(r48a4);
		rList.add(r50a4);
		rList.add(r52a4);
		rList.add(r54a4);
		rList.add(r56a4);
		rList.add(r58a4);
		rList.add(r60a4);

		rList.add(r62a5);
		rList.add(r64a5);
		rList.add(r66a5);
		rList.add(r68a5);
		// Create default armor and weapon for hero
		Armor defAm = new Armor("vest", 1, 1);
		Weapon defWp = new Weapon("dagger", 2, 40);
		ArrayList<Item> defaultInventory = new ArrayList<Item>();
		defaultInventory.add(defAm);
		defaultInventory.add(defWp);
		/// Create a new hero
		HeroNew hero = new HeroNew(nameHero);
		hero.addDefault(defaultInventory);
		hero.initializeRooms(rList);// rooms are added to hero class
		System.out.println("\n" + "\n=======================Area 1: Broken Cabin======================" + "\n");
		System.out.println(hero.getRoomDes());
		// System.out.println("-----Your default stats-------"+ "\n"+hero);

		String gameState = "start";

		while (gameState.equalsIgnoreCase("start")) {
			// check if there is nothing in the room
			if (hero.getRoom().getContain().equalsIgnoreCase("nth")) {
				System.out.println("There is nothing in this room!");
				System.out.println("1.Move \n2.View Default Stats \n3.Check Inventory \n4.View Hero");
				System.out.print("Choose:");
				String input = console.nextLine();
				checkQuit(input);
				System.out.println(input);
				while (!input.equals("1") && !input.equals("2") && !input.equalsIgnoreCase("3")
						&& !input.equalsIgnoreCase("4")) {
					System.out.print("Invalid input, Please input again:");
					input = console.nextLine();
				}
				if (input.equals("1")) {
					hero.move();
					System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
					System.out.println(hero.getRoomDes());
				} else if (input.equals("2")) {
					hero.getDefStat();
					System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
				} else if (input.equals("3")) {
					hero.checkInventory();
					System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
				} else if (input.equals("4")) {
					System.out.print(hero);
					System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
				}
				// check if there are items in the room
			} else if (hero.getRoom().getContain().equalsIgnoreCase("it")) {
				if (hero.getRoom().getContent().size() != 0) {
					System.out.println("There are items in this room you can pick up");
					System.out.println("1.Pick \n2.Drop \n3.Check Inventory \n4.Move \n5.View Hero");
					System.out.print("Choose:");
					String input = console.nextLine();
					checkQuit(input);
					while (!input.equals("1") && !input.equals("2") && !input.equals("3") && !input.equals("4")
							&& !input.equals("5")) {
						System.out.print("Invalid input, Please input again:");
						input = console.nextLine();
					}
					if (input.equals("1")) {
						hero.pick();
						System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
					} else if (input.equals("2")) {
						hero.drop();
						System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
					} else if (input.equals("3")) {
						hero.checkInventory();
						System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
					} else if (input.equals("4")) {
						hero.move();
						System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
						System.out.println(hero.getRoomDes());
					} else if (input.equals("5")) {
						System.out.print(hero);
						System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
					}
				} else {
					System.out.println("There is no more item to pick up");
					System.out.println("1.Drop \n2.Check Inventory \n3.Move \n4.View Hero");
					System.out.print("Choose:");
					String input = console.nextLine();
					checkQuit(input);
					while (!input.equals("1") && !input.equals("2") && !input.equals("3") && !input.equals("4")) {
						System.out.print("Invalid input, Please input again:");
						input = console.nextLine();
					}
					if (input.equals("1")) {
						hero.drop();
						System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
					} else if (input.equals("2")) {
						hero.checkInventory();
						System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
					} else if (input.equals("3")) {
						hero.move();
						System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
						System.out.println(hero.getRoomDes());
					} else if (input.equals("4")) {
						System.out.print(hero);
						System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
					}

				}

				// check if the room is a shop room
			} else if (hero.getRoom().getContain().equalsIgnoreCase("shop")) {
				System.out.println("You have entered a shop room!");
				System.out.println("1.Shop \n2.Drop \n3.Check Inventory \n4.Move \n5.View Hero \nChoose:");
				String input = console.nextLine();
				checkQuit(input);
				while (!input.equals("1") && !input.equals("2") && !input.equals("3") && !input.equals("4")
						&& !input.equals("5")) {
					System.out.print("Invalid input, Please input again:");
					input = console.nextLine();
				}
				if (input.equals("1")) {
					hero.shop();
					System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
				} else if (input.equals("2")) {
					hero.drop();
					System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
				} else if (input.equals("3")) {
					hero.checkInventory();
					System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
				} else if (input.equals("4")) {
					hero.move();
					System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
					System.out.println(hero.getRoomDes());
				} else if (input.equals("5")) {
					System.out.print(hero);
					System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
				}
			}
			// check if the room contain a monster
			else if (hero.getRoom().getContain().equalsIgnoreCase("mn")) {
				System.out.println(hero.getRoomDes());
				System.out.println("You have enountered a monster. You must fight!");
				String state = "yes";
				while (state.equalsIgnoreCase("yes")) {
					System.out.println("1.View Hero \n2.Examine Monster \nChoose:");
					String choose = console.nextLine();
					checkQuit(choose);
					while (!choose.equals("1") && !choose.equals("2")) {
						System.out.println("Invalid input, Please input again:");
						choose = console.nextLine();
					}
					if (choose.equals("1")) {
						System.out.print(hero);
						System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
					} else if (choose.equals("2")) {
						System.out.print((hero.getRoom().getMonster()));
						System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
					}
					System.out.println("\nExamine again: (yes/no)");
					state = console.nextLine();
					while (!state.equalsIgnoreCase("yes") && !state.equalsIgnoreCase("no")) {
						state = console.nextLine();
					}
				}
				hero.fight();
				System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
			}
		}
	}

}
