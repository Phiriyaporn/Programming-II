package Programming_II;

public interface item_selection {
	public void pick();

	public void drop();
}
