package Programming_II;

public class Armor extends Item {
	private int protention_level;
	private static String id = "am";
	private int price;

	public Armor(String name, int protention_level, int price) {
		super(name, id, price);
		this.protention_level = protention_level;
	}

	public int getProtention_level() {
		return protention_level;
	}

	public void setProtention_level(int protention_level) {
		this.protention_level = protention_level;
	}

	public static void setId(String id) {
		Armor.id = id;
	}

	public String toString() {
		return super.toString() + "Protection_Level:" + this.protention_level + "\n";
	}
}
