package Programming_II;

public class driverTest {

	public static void main(String[] args) {
		gamePlay game1 = new gamePlay("");
		game1.getPlayerName();
		game1.printStory();
		game1.printTutorial();
		game1.Play();

	}

}
