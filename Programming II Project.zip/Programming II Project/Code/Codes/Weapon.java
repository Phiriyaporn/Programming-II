package Programming_II;

public class Weapon extends Item {
	private int damage;
	private static String id = "wp";

	public Weapon(String name, int price, int damage) {
		super(name, id, price);
		this.damage = damage;

	}

	public String getName() {
		return this.name;
	}

	public int getDamage() {
		return damage;
	}

	public void setDamage(int damage) {
		this.damage = damage;
	}

	public static void setId(String id) {
		Weapon.id = id;
	}

	public String toString() {
		return super.toString() + "\nDamage:" + this.damage + "\n";
	}

}
