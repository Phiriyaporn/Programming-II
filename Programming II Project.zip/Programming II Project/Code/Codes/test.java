//package Programming_II;
//import java.util.*;
//public class test {
//
//	public static void main(String[] args) {
//		Weapon wp = new Weapon("Sword", 2, 3); 
//		Armor am = new Armor("MagicVest",5,2);
//		ArrayList<Item> wpList = new ArrayList<Item>();
//		wpList.add(wp);
//		wpList.add(am);
//		Monster mn = new Monster("Killa","sm", 13, 2, 2);
//		RoomNew r = new RoomNew(2, 6, 8, 4, 10, "wp", mn);
//		ArrayList<RoomNew> rList = new ArrayList<RoomNew>();
//		rList.add(r);
//		
//		Armor defAm = new Armor("vest",5,1);
//		Weapon defWp = new Weapon("dagger",2,10);
//		ArrayList<Item> defaultInventory = new ArrayList<Item>();
//		defaultInventory.add(defAm);
//		defaultInventory.add(defWp);
//		
//		Scanner console = new Scanner(System.in);
//		System.out.print("Enter Character Name:");
//		String playerName = console.nextLine();
//		HeroNew hero = new HeroNew(playerName);
//		hero.addDefault(defaultInventory);
//		hero.initializeRooms(rList);
//		System.out.println(hero);
//		System.out.println(mn);
//		hero.fight();
//		System.out.println(hero);
//		System.out.println(mn);
//		
//	}
//
//}
