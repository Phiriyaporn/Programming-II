package Programming_II;

public class Item {
	protected String name;
	protected String id;
	protected int price;

	public Item(String name, String id, int price) {
		this.name = name;
		this.id = id;
		this.price = price;
	}

	public String getName() {
		return this.name;
	}

	public String getId() {
		return this.id;
	}

	public int getPrice() {
		return this.price;
	}

	public String toString() {
		return "\nName:" + this.name + "\nPrice:" + this.price + "\n";
	}
}
