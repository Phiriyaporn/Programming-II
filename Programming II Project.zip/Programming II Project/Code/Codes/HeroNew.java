package Programming_II;

import java.util.ArrayList;
import java.util.Scanner;

public class HeroNew implements travel, item_selection, battle {
	// Location Based stuff
	private ArrayList<RoomNew> roomList;// all the room are placed in the hero class
	private int CurrentRoom;
	private int HeroLvl;
	private String HeroName;
	private int health;
	protected int HeroDef;
	protected int currency;
	protected ArrayList<Item> inventory;

	// Once hero is created, default statistics are given
	public HeroNew(String PlayerName) {
		CurrentRoom = 2;
		this.HeroName = PlayerName;
		this.health = 20;
		this.HeroDef = 20;

	}

	// return hero information
	public String toString() {
		return "Name:" + this.HeroName + "\nCurrentRoom:" + this.CurrentRoom + "\nHealth:" + this.health + "\nDefense:"
				+ this.HeroDef + "\nHeroLevel:" + this.HeroLvl + "\nCurrency:" + this.currency;
	}

	// Get the room description
	public String getRoomDes() {
		RoomNew r = getRoom();
		return r.getRoomDes();
	}

	// check for game termination
	public void checkQuit(String input) {
		if (input.equalsIgnoreCase("quit") || input.equalsIgnoreCase("exit")) {
			System.out.println("Bye For now!");
			System.exit(0);
		}
	}

	// Method to verify input
	public boolean checker(String[] accepted, String input) {
		for (int d = 0; d < accepted.length; d++) {
			if (accepted[d].equals(input)) {
				return true;
			}

		}
		return false;
	}

	@Override
	// implement the move interface
	public void move() {
		RoomNew r = getRoom();
		Scanner console = new Scanner(System.in);
		// get the directions and the ID of the rooms
		ArrayList<String> direction = new ArrayList<String>();
		ArrayList<Integer> idPointer = new ArrayList<Integer>();
		if (r.getNorth() != 0) {
			direction.add("Move North");
			idPointer.add(r.getNorth());
		}
		if (r.getEast() != 0) {
			direction.add("Move East");
			idPointer.add(r.getEast());
		}
		if (r.getSouth() != 0) {
			direction.add("Move South");
			idPointer.add(r.getSouth());
		}
		if (r.getWest() != 0) {
			direction.add("Move West");
			idPointer.add(r.getWest());
		}

		for (int i = 0; i < direction.size(); i++) {
			System.out.println(i + "." + direction.get(i));
		}

		String[] accepted = new String[direction.size()];
		for (int i = 0; i < direction.size(); i++) {
			String temp = Integer.toString(i);
			accepted[i] = temp;
		}
		// Ask the player to enter value to move
		System.out.print("Move where? Enter value:");
		String move = console.nextLine();
		checkQuit(move);

		while (checker(accepted, move) == false) {
			System.out.print("Invalid input, Enter again:");
			move = console.nextLine();
			checkQuit(move);
		}

		int moved = Integer.parseInt(move);

		for (int k = 0; k < direction.size(); k++) {
			if (moved == k) {
				this.CurrentRoom = idPointer.get(k);
			}
		}
	}

	// Add all rooms to hero class
	public void initializeRooms(ArrayList<RoomNew> rooms) {
		this.roomList = rooms;
	}

	// Return the current at the character is in
	public RoomNew getRoom() {
		int position = 0;
		for (int i = 0; i < this.roomList.size(); i++) {
			if (roomList.get(i).getId() == this.CurrentRoom) {
				position = i;
			}
		}
		return roomList.get(position);
	}

	// Add default information
	public void addDefault(ArrayList<Item> defaultItems) {
		this.inventory = defaultItems;
		for (int i = 0; i < inventory.size(); i++) {
			if (inventory.get(i).getId().equals("am")) {
				Armor temp = (Armor) inventory.get(i);
				this.HeroDef = this.HeroDef + temp.getProtention_level();
			}
		}
		this.currency = 10;
	}

	// Get default information
	public void getDefStat() {
		System.out.println("\nName:" + this.HeroName + "\nHealth:" + this.health + "\nDefense:" + this.HeroDef
				+ "\nCurreny:" + this.currency);
	}

	// Print out what is in the inventory
	public void checkInventory() {
		if (inventory.size() != 0) {
			System.out.print("Here is you inventory.\n");
			for (int i = 0; i < inventory.size(); i++) {
				System.out.print("*" + inventory.get(i));
			}
		} else {
			System.out.println("Inventory is empty!");
		}
	}

	// Place the hero back in the respawn room when got defeated
	public void respawn() {
		RoomNew r = getRoom();
		System.out.println("You have been respawned. You are placed back in the respawn room");
		this.CurrentRoom = roomList.get(0).getId();
		move();

	}

	// Method that increase character level;
	public void increaseLevel() {
		this.HeroLvl++;
		this.HeroDef = this.HeroDef + 12;
		this.health = this.health + 10;
		this.CurrentRoom = roomList.get(5).getId();
	}

	@Override
	// implement the pick method
	public void pick() {
		Scanner console = new Scanner(System.in);
		int currentInventorySpace = inventory.size();
		RoomNew r = getRoom();
		if (r.getContent().size() != 0) {
			System.out.println("Here is items in this room to pick up");
			for (int i = 0; i < r.getContent().size(); i++) {
				System.out.print("[" + i + ".]" + r.getContent().get(i));
			}

			String[] accepted = new String[r.getContent().size()];
			for (int i = 0; i < r.getContent().size(); i++) {
				String temp = Integer.toString(i);
				accepted[i] = temp;
			}
			System.out.print("Enter the number to pick item:");
			String pick = console.nextLine();
			checkQuit(pick);
			// verify input
			while (checker(accepted, pick) == false) {
				System.out.print("Invalid input, Enter again:");
				pick = console.nextLine();
				checkQuit(pick);
			}

			int picked = Integer.parseInt(pick);

			for (int k = 0; k < r.getContent().size(); k++) {
				if (k == picked) {
					if (currentInventorySpace <= 10) {
						inventory.add(r.getContent().get(k));
						if (r.getContent().get(k).getId().equals("am")) {
							Armor temp = (Armor) r.getContent().get(k);
							int defUp = temp.getProtention_level();
							this.HeroDef = this.HeroDef + defUp;
						}
						System.out.println("You have picked up " + r.getContent().get(k).getName());
						r.getContent().remove(k);
					} else {
						System.out.println("Inventory is full, you must drop some items");
					}
				}
			}

		} else {
			System.out.println("There is nothing left for you to pick up");
		}
	}

	@Override
	// Implement the drop method
	public void drop() {
		Scanner console = new Scanner(System.in);
		RoomNew r = getRoom();
		if (inventory.size() != 0) {
			System.out.println("Here are the items you can drop");
			for (int i = 0; i < inventory.size(); i++) {
				System.out.println("[" + i + ".]" + inventory.get(i));
			}
			String[] accepted = new String[inventory.size()];
			for (int i = 0; i < inventory.size(); i++) {
				String temp = Integer.toString(i);
				accepted[i] = temp;
			}
			System.out.println("Enter Number to Drop Item:");
			String itemToDrop = console.nextLine();
			checkQuit(itemToDrop);

			while (checker(accepted, itemToDrop) == false) {
				System.out.print("Invalid input, Enter again:");
				itemToDrop = console.nextLine();
				checkQuit(itemToDrop);
			}

			int dropped = Integer.parseInt(itemToDrop);
			for (int k = 0; k < inventory.size(); k++) {
				if (k == dropped) {
					r.getContent().add(inventory.get(k));
					if (inventory.get(k).getId().equals("am")) {
						Armor temp = (Armor) inventory.get(k);
						this.HeroDef = this.HeroDef - temp.getProtention_level();
						inventory.remove(k);
						System.out.println("You have removed " + temp.getName() + ".");
					} else {
						System.out.println("You have removed " + inventory.get(k).getName() + ".");
						inventory.remove(k);
					}
				}
			}
		} else {
			System.out.println("There is nothing left in your inventory to drop");
		}
	}

	@Override
	// This is method for fighting
	public void fight() {

		Scanner console = new Scanner(System.in);
		RoomNew r = getRoom();
		String monType = r.getMonster().getType();
		// fight implementation for normal monster
		if (monType.equals("nm")) {
			boolean state = true;
			while (state) {
				System.out.println("You have encounter a normal monster " + r.getMonster().getName() + " with health "
						+ r.getMonster().getHealth());
				// check for weapons in inventory
				ArrayList<Weapon> wpToUse = new ArrayList<Weapon>();
				for (int k = 0; k < inventory.size(); k++) {
					if (this.inventory.get(k).getId().equals("wp")) {
						wpToUse.add((Weapon) inventory.get(k));
					}
				}
				System.out.println("Here is the list of weapon to choose from");
				boolean wpStatus = true;
				if (wpToUse.size() != 0) {
					for (int k = 0; k < wpToUse.size(); k++) {
						System.out.println(k + "." + wpToUse.get(k).getName());
					}

					String[] accepted = new String[wpToUse.size()];
					for (int i = 0; i < wpToUse.size(); i++) {
						String temp = Integer.toString(i);
						accepted[i] = temp;
					}
					System.out.println("Choose:");
					String choice = console.nextLine();
					checkQuit(choice);

					while (checker(accepted, choice) == false) {
						System.out.print("Invalid input, Enter again:");
						choice = console.nextLine();
						checkQuit(choice);
					}

					int chose = Integer.parseInt(choice);

					for (int j = 0; j < wpToUse.size(); j++) {
						if (chose == j) {
							Weapon temp = (Weapon) wpToUse.get(j);
							System.out.println("You hit monster for " + temp.getDamage() + " damages");
							int baseDef = r.getMonster().getDefense();
							int newDef = r.getMonster().getDefense() - temp.getDamage();
							r.getMonster().setDefense(newDef);
							if (newDef <= 0) {
								int extraDmg = Math.abs(baseDef - temp.getDamage());
								int newHealth = r.getMonster().getHealth() - extraDmg;
								r.getMonster().setHealth(newHealth);
								r.getMonster().setDefense(0);
							}
							if (r.getMonster().getHealth() <= 0) {
								r.getMonster().setHealth(0);
							}
							if (r.getMonster().getHealth() <= 0) {
								System.out.println("The Monster health is 0");
							} else {
								System.out.println("The Monster health is " + r.getMonster().getHealth());
							}
							System.out.println("The monster hit you for " + r.getMonster().getDamage() + " damages");
							int baseDefH = this.HeroDef;
							int newDefH = this.HeroDef - r.getMonster().getDamage();
							this.HeroDef = newDefH;
							if (newDefH <= 0) {
								int extraDamage = Math.abs(baseDefH - r.getMonster().getDamage());
								int newHealthH = this.health - extraDamage;
								this.health = newHealthH;
								this.HeroDef = 0;
							}
							if (this.health <= 0) {
								this.health = 0;
							}
							System.out.println("You health is " + this.health);
						}
					}
					if (this.health <= 0) {
						System.out.println("You were defeated in the fight and lost conscious."
								+ "When you regain your consciousness, you found yourself back at the start.");
						respawn();
						wpStatus = false;
					} else if (r.getMonster().getHealth() <= 0) {
						System.out.println("The monster is defeated\n" + "\n===========================");
						this.currency = this.currency + 5;
						System.out.println(getRoomDes());
						move();
						wpStatus = false;
					}
				} else {
					System.out.println("You have no weapon to fight with. You have been slain by the monster");
					respawn();
					wpStatus = false;
				}
				state = wpStatus;
			}
		}
		// fight implementation for special monster
		else if (monType.equals("sm")) {
			boolean state = true;
			while (state) {
				boolean weaponStatus = true;
				System.out.println("You have encounter a special monster " + r.getMonster().getName() + " with health "
						+ r.getMonster().getHealth());
				ArrayList<Weapon> wpToUse1 = new ArrayList<Weapon>();
				for (int k = 0; k < inventory.size(); k++) {
					if (this.inventory.get(k).getId().equals("wp")) {
						wpToUse1.add((Weapon) inventory.get(k));
					}
				}
				if (wpToUse1.size() <= 0) {
					System.out.println("Here is the list of weapons to choose from");
					for (int k = 0; k < wpToUse1.size(); k++) {
						System.out.println(k + "." + wpToUse1.get(k).getName());
					}

					String[] accepted = new String[wpToUse1.size()];
					for (int i = 0; i < wpToUse1.size(); i++) {
						String temp = Integer.toString(i);
						accepted[i] = temp;
					}
					System.out.println("Choose:");
					String choice = console.nextLine();
					checkQuit(choice);
					while (checker(accepted, choice) == false) {
						System.out.print("Invalid input, Enter again:");
						choice = console.nextLine();
						checkQuit(choice);
					}
					int chose = Integer.parseInt(choice);
					for (int j = 0; j < wpToUse1.size(); j++) {
						if (chose == j) {
							Weapon temp = (Weapon) wpToUse1.get(j);
							System.out.println("You hit monster for " + temp.getDamage() + " damages");
							int baseDef = r.getMonster().getDefense();
							int newDef = r.getMonster().getDefense() - temp.getDamage();
							r.getMonster().setDefense(newDef);
							if (newDef <= 0) {
								int extraDmg = Math.abs(baseDef - temp.getDamage());
								int newHealth = r.getMonster().getHealth() - extraDmg;
								r.getMonster().setHealth(newHealth);
								r.getMonster().setDefense(0);
							}
							if (r.getMonster().getHealth() <= 0) {
								r.getMonster().setHealth(0);
							}
							System.out.println("The Monster health is " + r.getMonster().getHealth());

							System.out.println("The monster hit you for " + r.getMonster().getDamage() + " damages");
							int baseDefH = this.HeroDef;
							int newDefH = this.HeroDef - r.getMonster().getDamage();
							this.HeroDef = newDefH;
							if (newDefH <= 0) {
								int extraDamage = Math.abs(baseDefH - r.getMonster().getDamage());
								int newHealthH = this.health - extraDamage;
								this.health = newHealthH;
								this.HeroDef = 0;
							}
							if (this.health <= 0) {
								this.health = 0;
							}
							System.out.println("You health is " + this.health);
						}
					}
					if (this.health <= 0) {
						System.out.println("You were defeated in the fight and lost conscious."
								+ "When you regain your conscious, you found yourself back at the start.");
						respawn();
						weaponStatus = false;
					} else if (r.getMonster().getHealth() <= 0) {
						System.out.println("The monster is defeated.");
						Armor specialOb = new Armor("Golden_Vest", 40, 50);
						System.out.println("You have retrieved a Golden_Vest!");
						inventory.add(specialOb);
						move();
						weaponStatus = false;
					}
				} else {
					System.out.println("You don't have a weapon to fight.  You got slained by monter");
					respawn();
					weaponStatus = false;
				}

				state = weaponStatus;
			}
		}
		// fight method for boss monster
		else if (monType.equals("bm")) {
			boolean state = true;
			while (state) {
				boolean wPStat = true;
				System.out.println("You have encounter a boss monster " + r.getMonster().getName() + " with health "
						+ r.getMonster().getHealth());
				ArrayList<Weapon> wpToUse2 = new ArrayList<Weapon>();
				for (int k = 0; k < inventory.size(); k++) {
					if (this.inventory.get(k).getId().equals("wp")) {
						wpToUse2.add((Weapon) inventory.get(k));
					}
				}
				if (wpToUse2.size() != 0) {
					boss_monster bm = (boss_monster) r.getMonster();
					int orgDef = bm.getDefense();
					int orgHealth = bm.getHealth();
					int healCount = bm.getHeal_count();
					while (healCount != 0) {
						System.out.println("Here is the list of weapons to choose from");
						for (int k = 0; k < wpToUse2.size(); k++) {
							System.out.println(k + "." + wpToUse2.get(k).getName());
						}
						String[] accepted = new String[wpToUse2.size()];
						for (int i = 0; i < wpToUse2.size(); i++) {
							String temp = Integer.toString(i);
							accepted[i] = temp;
						}
						System.out.println("Choose:");
						String choice = console.nextLine();
						checkQuit(choice);

						while (checker(accepted, choice) == false) {
							System.out.print("Invalid input, Enter again:");
							choice = console.nextLine();
							checkQuit(choice);
						}

						int chose = Integer.parseInt(choice);

						for (int j = 0; j < wpToUse2.size(); j++) {
							if (chose == j) {
								Weapon temp = (Weapon) wpToUse2.get(j);
								System.out.println("You hit monster for " + temp.getDamage() + " damages");
								int baseDef = r.getMonster().getDefense();
								int newDef = r.getMonster().getDefense() - temp.getDamage();
								r.getMonster().setDefense(newDef);
								if (newDef <= 0) {
									int zero = 0;
									int extraDmg = Math.abs(baseDef - temp.getDamage());
									int newHealth = r.getMonster().getHealth() - extraDmg;
									r.getMonster().setHealth(newHealth);
									r.getMonster().setDefense(zero);
								}
								int baseDefH = this.HeroDef;
								int newDefH = this.HeroDef - r.getMonster().getDamage();
								this.HeroDef = newDefH;
								if (newDefH <= 0) {
									int extraDamage = Math.abs(baseDefH - r.getMonster().getDamage());
									int newHealthH = this.health - extraDamage;
									this.health = newHealthH;
									this.HeroDef = 0;
								}
								if (this.health <= 0) {
									this.health = 0;
								}
								System.out.println("You health is " + this.health);
								if (r.getMonster().getHealth() <= 0) {
									System.out.println("The Monster health is 0");
								} else {
									System.out.println("The Monster health is " + r.getMonster().getHealth());
								}
								System.out
										.println("The monster hit you for " + r.getMonster().getDamage() + " damages");
								if (this.health <= 0) {
									System.out.println("You were defeated in the fight and lost conscious."
											+ "When you regain your conscious, you found yourself back at the start.");
									respawn();
									healCount = 0;
									wPStat = false;
								} else if (r.getMonster().getHealth() <= 0) {
									bm.setDefense(orgDef);
									bm.setHealth(orgHealth);
									healCount--;

								}
							}
						}
						if (healCount == 0) {
							System.out.println("The boss monster is defeated!!\n" + "\n"
									+ "The Beast fell onto the ground, before disintegrating into Ash. In it's place was a shiny little blue cube.\n"
									+ "\n"
									+ "You pick it up, causing it to shudder and glow into a blinding flash of light!\n"
									+ "\n" + "-----Hero Level up!!!-------\n");
							System.out.println(
									"==========================Area 2:Land of Fire Flies and Moss ================================");
							System.out.println("You have now move to next area in the first respawn room");
							System.out.println(roomList.get(5).getRoomDes());
							increaseLevel();
							healCount = 0;
							wPStat = false;
							break;
						}
						// System.out.println("The boss monster is defeated!!" + "-----Hero Level
						// up!!!-------\n");
						// System.out.println(
						// "==========================Area 2:Land of Fire Flies and Moss
						// ================================");
						// System.out.println("You have now move to next area in the first respawn
						// room");
						// increaseLevel();
						// healCount = 0;
						// wPStat = false;

					}

				} else {
					System.out.println("You have no weapon! You have been slained!");
					respawn();
					wPStat = false;
				}

				state = wPStat;
			}

		}
		// outside state loop

	}

	// Methods that allows character to buy and sell items
	public void shop() {
		Scanner console = new Scanner(System.in);
		RoomNew r = getRoom();
		String shop = "yes";
		while (shop.equalsIgnoreCase("yes")) {
			System.out.print("Do you want to buy or sell?");
			String input = console.nextLine();
			checkQuit(input);
			while (!input.equalsIgnoreCase("buy") && !input.equalsIgnoreCase("sell")) {
				System.out.print("Please type in 'buy' or 'sell' :");
				input = console.nextLine();
				checkQuit(input);
			}
			// when player enter 'buy'
			if (input.equalsIgnoreCase("buy")) {
				int shopCount = r.getContent().size();
				while (shopCount != 0) {
					System.out.println("Here is a list of items you can buy");
					for (int i = 0; i < r.getContent().size(); i++) {
						System.out.println(
								i + "." + r.getContent().get(i).getName() + "-----" + r.getContent().get(i).getPrice());
					}

					String[] accepted = new String[r.getContent().size()];
					for (int i = 0; i < r.getContent().size(); i++) {
						String temp = Integer.toString(i);
						accepted[i] = temp;
					}
					System.out.println("Choose:");
					String choice = console.nextLine();
					checkQuit(choice);
					while (checker(accepted, choice) == false) {
						System.out.print("Invalid input, Enter again:");
						choice = console.nextLine();
						checkQuit(choice);
					}
					int chose = Integer.parseInt(choice);
					for (int k = 0; k < r.getContent().size(); k++) {
						if (chose == k) {
							if (this.currency >= r.getContent().get(k).getPrice()) {
								this.inventory.add(r.getContent().get(k));
								System.out
										.println("You have successfully purchased " + r.getContent().get(k).getName());
								this.currency = this.currency - r.getContent().get(k).getPrice();
								r.getContent().remove(k);
							} else {
								System.out.println("You don't have enough money!!!!!!");
							}
						}

					}
					System.out.print("Buy again:(1/0)");

					String dec = console.nextLine();
					checkQuit(dec);
					while (!dec.equalsIgnoreCase("1") && !dec.equalsIgnoreCase("0")) {
						System.out.print("I don't understand: Please type '1' or '0':");
						dec = console.nextLine();
						checkQuit(dec);
					}
					int decided = Integer.parseInt(dec);

					shopCount = decided;
				}
			}
			// when player enters 'sell'
			else if (input.equalsIgnoreCase("sell")) {
				int size = this.inventory.size();
				if (size != 0) {
					System.out.println("Here is a list of items you can sell");
					while (size != 0) {
						for (int i = 0; i <= this.inventory.size(); i++) {
							try {
								System.out.println(i + "." + inventory.get(i).getName() + "--"
										+ inventory.get(i).getPrice() + "BitZ");
							} catch (Exception e) {
								System.out.println("You have nothing to sell");
							}
						}

						String[] accepted = new String[inventory.size()];
						for (int i = 0; i < inventory.size(); i++) {
							String temp = Integer.toString(i);
							accepted[i] = temp;
						}
						System.out.print("Choose:");
						String sellChoice = console.nextLine();
						checkQuit(sellChoice);
						while (checker(accepted, sellChoice) == false) {
							System.out.print("Invalid input, Enter again:");
							sellChoice = console.nextLine();
							checkQuit(sellChoice);
						}
						int chose = Integer.parseInt(sellChoice);
						for (int k = 0; k < this.inventory.size(); k++) {
							if (chose == k) {
								System.out.println("You have sold " + this.inventory.get(k).getName());
								this.currency = this.currency + inventory.get(k).getPrice();
								r.getContent().add(this.inventory.get(k));
								this.inventory.remove(k);

							}
						}
						System.out.print("Sell again(1/0)");
						String inp = console.nextLine();
						checkQuit(inp);
						while (!inp.equalsIgnoreCase("1") && !inp.equalsIgnoreCase("0")) {
							System.out.print("I don't understand, please type in '1' or '0':");
							inp = console.nextLine();
							checkQuit(inp);
						}
						int sold = Integer.parseInt(inp);
						size = sold;
					}
				} else {
					System.out.println("You have nothing to sell");
				}
			}
			System.out.print("Do you want to buy or sell again(yes/no)?");
			String rep = console.nextLine();
			checkQuit(rep);
			while (!rep.equalsIgnoreCase("yes") && !rep.equalsIgnoreCase("no")) {
				System.out.print("Invalid input, please type in 'yes' or 'no'");
				rep = console.nextLine();
				checkQuit(rep);
			}
			shop = rep;
		}
	}
}
