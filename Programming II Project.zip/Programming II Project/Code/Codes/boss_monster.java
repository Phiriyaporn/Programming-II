package Programming_II;

public class boss_monster extends Monster {
	private int heal_count;
	private static String id = "bm";

	public boss_monster(String name, int health, int defense, int damage, int heal_count) {
		super(name, id, health, defense, damage);
		this.heal_count = heal_count;
	}

	public int getHeal_count() {
		return heal_count;
	}

	public String getId() {
		return this.id;
	}

	public void setHeal_count(int heal_count) {
		this.heal_count = heal_count;
	}

	public String toString() {
		return super.toString() + "\nHeal_Count:" + this.heal_count;
	}

}
