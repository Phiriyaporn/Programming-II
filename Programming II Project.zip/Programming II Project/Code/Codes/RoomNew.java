package Programming_II;

import java.util.ArrayList;

public class RoomNew {
	private int Id;
	private String Des;
	private int North;
	private int East;
	private int South;
	private int West;
	private String contain;
	private ArrayList<Item> content;
	private Monster monster;

	public RoomNew(int id, String Des, int north, int east, int south, int west, String contain,
			ArrayList<Item> content) {
		this.Id = id;
		this.Des = Des;
		this.North = north;
		this.East = east;
		this.South = south;
		this.West = west;
		this.contain = contain;
		this.content = content;
	}

	public RoomNew(int id, String Des, int north, int east, int south, int west, String contain, Monster monster) {
		Id = id;
		this.Des = Des;
		this.North = north;
		this.East = east;
		this.South = south;
		this.West = west;
		this.contain = contain;
		this.monster = monster;
	}

	public String toString() {
		return "Id:" + this.Id + "\nContent:" + this.content;
	}

	public int getId() {
		return Id;
	}

	public String getRoomDes() {
		return this.Des;
	}

	public int getNorth() {
		return North;
	}

	public int getEast() {
		return East;
	}

	public int getSouth() {
		return South;
	}

	public int getWest() {
		return West;
	}

	public String getContain() {
		return this.contain;
	}

	public ArrayList<Item> getContent() {
		return content;
	}

	public Monster getMonster() {
		return this.monster;
	}

	public void setId(int id) {
		Id = id;
	}

	public void setNorth(int north) {
		North = north;
	}

	public void setEast(int east) {
		East = east;
	}

	public void setSouth(int south) {
		South = south;
	}

	public void setWest(int west) {
		West = west;
	}

	public void setContentId(String contain) {
		this.contain = contain;
	}

	public void setContent(ArrayList<Item> content) {
		this.content = content;
	}

}