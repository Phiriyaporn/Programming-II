package Programming_II;

public class Monster {
	protected String name;
	protected int health;
	protected int defense;
	protected int damage;
	protected String type;

	public Monster(String name, String type, int health, int defense, int damage) {
		this.name = name;
		this.type = type;
		this.health = health;
		this.defense = defense;
		this.damage = damage;
	}

	public String getName() {
		return name;
	}

	public String getType() {
		return this.type;
	}

	public int getHealth() {
		return health;
	}

	public int getDefense() {
		return this.defense;
	}

	public int getDamage() {
		return damage;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setHealth(int health) {
		this.health = health;
	}

	public void setDefense(int defense) {
		this.defense = defense;
	}

	public void setDamage(int damage) {
		this.damage = damage;
	}

	public String toString() {
		return "Name:" + this.name + "\n-Health:" + this.health + "\n-Defense:" + this.defense + "\nDamage:"
				+ this.damage;
	}
}
