package Programming_II;

import java.util.ArrayList;
import java.util.Scanner;

public class checker {

	public static void main(String[] args) {
		Scanner console = new Scanner(System.in);
		ArrayList<Integer> test = new ArrayList<Integer>();
		test.add(1);
		test.add(2);
		test.add(3);
		String[] accepted = new String[test.size()];
		for (int i = 0; i < test.size(); i++) {
			String temp = Integer.toString(i);
			accepted[i] = temp;
		}
		System.out.print("Enter integer:");
		String input = console.nextLine();
		System.out.println(checker(accepted, input));
		while (checker(accepted, input) == false) {
			System.out.print("Invalid input, Enter again:");
			input = console.nextLine();
		}
	}

	public static boolean checker(String[] accepted, String input) {
		for (int d = 0; d < accepted.length; d++) {
			if (accepted[d].equals(input)) {
				return true;
			}

		}
		return false;
	}

}
