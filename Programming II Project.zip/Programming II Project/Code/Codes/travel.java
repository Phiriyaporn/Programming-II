package Programming_II;

public interface travel {
	public void move();
}
